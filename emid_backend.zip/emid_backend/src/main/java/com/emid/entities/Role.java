

package com.emid.entities;

public enum Role {
	ROLE_DOCTOR,ROLE_ADMIN,ROLE_PATIENT

}
