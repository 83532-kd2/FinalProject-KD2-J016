package com.emid.entities;

public enum BooleanStatus {
	TRUE,FALSE

}
