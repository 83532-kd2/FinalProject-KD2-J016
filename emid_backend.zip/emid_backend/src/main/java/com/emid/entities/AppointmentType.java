package com.emid.entities;

public enum AppointmentType {
    CONSULTATION,
    FOLLOW_UP,
    SURGERY,
    CHECK_UP,
    GENERAL
}
