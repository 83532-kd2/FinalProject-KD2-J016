import React from "react";

const Empty = () => {
  return <h2 className="nothing flex-center">Nothing to show</h2>;
};

export default Empty;
